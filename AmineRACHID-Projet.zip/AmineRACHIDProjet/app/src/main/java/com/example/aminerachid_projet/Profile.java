package com.example.aminerachid_projet;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;

public class Profile extends AppCompatActivity {

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://aminerachid-projet-e3005-default-rtdb.firebaseio.com/");

    Uri imageUri;
    String myUri = "";
    StorageTask<UploadTask.TaskSnapshot> uploadTask;
    StorageReference storageProfilePicsRef;
    private static final int PICK_IMAGE_REQUEST = 1;
    FirebaseAuth mAuth;

    private static final int PICK_IMAGE_REQUEST_CAMERA = 2;
    private static final int PICK_IMAGE_REQUEST_GALLERY = 3;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Intent intent = getIntent();
        final String email = intent.getStringExtra("email");
        final String password = intent.getStringExtra("password");

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.bottom_profile);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.bottom_map:
                    Intent intent1 = new Intent(Profile.this, MapActivity.class);
                    intent1.putExtra("email", email);
                    intent1.putExtra("password", password);
                    startActivity(intent1);
                    overridePendingTransition(R.anim.slid_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.bottom_activity:
                    Intent intent2 = new Intent(Profile.this, Activity.class);
                    intent2.putExtra("email", email);
                    intent2.putExtra("password", password);
                    startActivity(intent2);
                    overridePendingTransition(R.anim.slid_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.bottom_logout:
                    startActivity(new Intent(getApplicationContext(), Login.class));
                    overridePendingTransition(R.anim.slid_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.bottom_profile:

                    return true;
            }
            return false;
        });


        final CircleImageView profileImageView = findViewById(R.id.profile);

        final TextView profileChangeBtn = findViewById(R.id.change_profile);


        final RadioButton maleRadioBtn = findViewById(R.id.maleRadioButton);
        final RadioButton femaleRadioBtn = findViewById(R.id.femaleRadioButton);
        final EditText nameEditText = findViewById(R.id.nameEditText);
        final EditText phoneEditText = findViewById(R.id.phoneEditText);
        final EditText filliere = findViewById(R.id.fillier);
        final EditText emailTextView = findViewById(R.id.emailTextView);
        final EditText passwordTextView = findViewById(R.id.passwordTextView);

        emailTextView.setText(email);
        passwordTextView.setText(password);
        emailTextView.setEnabled(false);
        passwordTextView.setEnabled(false);
        Button updateButton = findViewById(R.id.updateButton);

        final String emailKey = email.replace(".", ",");

        mAuth = FirebaseAuth.getInstance();
        storageProfilePicsRef = FirebaseStorage.getInstance().getReference().child("Profile Pic");
        // Add an OnClickListener to the profileChangeBtn
        profileChangeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a chooser dialog to select between camera and gallery
                AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
                builder.setTitle("Select Picture");
                String[] options = {"Camera", "Gallery"};
                if (ContextCompat.checkSelfPermission(Profile.this, Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                    // Permission is not granted, request it
                    ActivityCompat.requestPermissions(Profile.this, new String[]{Manifest.permission.CAMERA},
                            CAMERA_PERMISSION_REQUEST_CODE);
                }
                builder.setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            // Open the camera to capture a new image
                            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                                startActivityForResult(cameraIntent, PICK_IMAGE_REQUEST_CAMERA);
                            }
                        } else if (which == 1) {
                            // Open the gallery to choose an image
                            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            startActivityForResult(galleryIntent, PICK_IMAGE_REQUEST_GALLERY);
                        }
                    }
                });
                builder.show();
            }
        });

        // Ajouter un ValueEventListener pour récupérer les données de l'utilisateur
        databaseReference.child("users").child(emailKey).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String fullname = snapshot.child("fullname").getValue(String.class);
                    String phone = snapshot.child("phone").getValue(String.class);
                    String fillieree = snapshot.child("major").getValue(String.class);
                    String gender = snapshot.child("gender").getValue(String.class);
                    // Mettre à jour l'interface utilisateur avec les valeurs récupérées
                    if (fillieree != null){
                        filliere.setText(fillieree);
                    }
                    if (gender != null && gender.equals("female")) {
                        femaleRadioBtn.setChecked(true);
                    } else {
                        maleRadioBtn.setChecked(true);
                    }

                    nameEditText.setText(fullname);
                    phoneEditText.setText(phone);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Gérer les erreurs de lecture depuis Firebase
            }
        });

        // Check if the user's profile image exists in Firebase Storage
        databaseReference.child("users").child(emailKey).child("profileImageUrl")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            String imagee = snapshot.getValue(String.class);
                            System.out.println("Image URL: " + imagee);
                            Picasso.get().load(imagee).into(profileImageView);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Handle errors during the database read operation
                    }
                });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String selectedGender = maleRadioBtn.isChecked() ? "male" : "female";
                final String newName = nameEditText.getText().toString();
                final String fillier = filliere.getText().toString();
                final String newPhone = phoneEditText.getText().toString();

                uploadImageToFirebase(emailKey);

                // Mettre à jour les informations dans la base de données Firebase
                databaseReference.child("users").child(emailKey).child("gender").setValue(selectedGender);
                databaseReference.child("users").child(emailKey).child("major").setValue(fillier);
                databaseReference.child("users").child(emailKey).child("fullname").setValue(newName);
                databaseReference.child("users").child(emailKey).child("phone").setValue(newPhone);

                Toast.makeText(Profile.this, "Profile updated successfully.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Profile.this, Activity.class);
                intent.putExtra("email", email);
                intent.putExtra("password", password);
                startActivity(intent);
                finish();
            }
        });

    }

    // Handle the result of the image picker
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        final CircleImageView profileImageView = findViewById(R.id.profile);

        if (resultCode == RESULT_OK) {
            if (requestCode == PICK_IMAGE_REQUEST_GALLERY && data != null) {
                // Get the selected image URI from the gallery
                Uri imageUri = data.getData();
                // Set the imageUri to the class variable
                this.imageUri = imageUri;
                // Load the selected image into the profileImageView using Picasso or Glide
                Picasso.get().load(imageUri).into(profileImageView);
            } else if (requestCode == PICK_IMAGE_REQUEST_CAMERA && data != null) {
                // Get the captured image from the camera
                Bundle extras = data.getExtras();
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                // Convert the Bitmap to Uri
                Uri imageUri = getImageUri(Profile.this, imageBitmap);
                // Set the imageUri to the class variable
                this.imageUri = imageUri;
                // Load the selected image into the profileImageView using Picasso or Glide
                Picasso.get().load(imageUri).into(profileImageView);
            }
        }
    }

    // Helper method to convert a Bitmap to Uri
    private Uri getImageUri(Context context, Bitmap bitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(context.getContentResolver(), bitmap, "Title", null);
        return Uri.parse(path);
    }


    private void uploadImageToFirebase(String emailKey) {
        if (imageUri != null) {

            // Generate a random name for the image file
            final String randomKey = UUID.randomUUID().toString();

            // Create a reference to the storage location where the image will be uploaded
            final StorageReference imageRef = storageProfilePicsRef.child(randomKey+".jpg");

            // Upload the image file to Firebase Storage
            uploadTask = imageRef.putFile(imageUri);

            // Monitor the upload progress
            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }

                    // Return the download URL of the uploaded image
                    return imageRef.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();

                        // Save the download URL to a variable or Firebase Realtime Database
                        myUri = downloadUri.toString();

                        // Update the user's profile with the image URL
                        databaseReference.child("users").child(emailKey).child("profileImageUrl").setValue(myUri);

                        // Display a success message
                        Toast.makeText(Profile.this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        // Handle errors that occurred during the upload
                        Toast.makeText(Profile.this, "Failed to upload image", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Profile.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show();
        }
    }

}