package com.example.aminerachid_projet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Activity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float[] gravity = new float[3];
    private float[] linear_acceleration = new float[3];
    private TextView statusTextView;
    private TextView activityStandingConfidenceTextView;
    private TextView activitySittingConfidenceTextView;
    private TextView activityWalkingConfidenceTextView;
    private TextView activityJumpingConfidenceTextView;
    private TextView activitySt;
    private TextView activitySi;
    private TextView activityWa;
    private TextView activityJu;

    private int[] confidenceValues = new int[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_);

        Intent intent = getIntent();
        final String email = intent.getStringExtra("email");
        final String password = intent.getStringExtra("password");

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.bottom_activity);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.bottom_map:
                    Intent intent1 = new Intent(Activity.this, MapActivity.class);
                    intent1.putExtra("email", email);
                    intent1.putExtra("password", password);
                    startActivity(intent1);
                    overridePendingTransition(R.anim.slid_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.bottom_activity:

                    return true;
                case R.id.bottom_logout:
                    startActivity(new Intent(getApplicationContext(), Login.class));
                    overridePendingTransition(R.anim.slid_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
                case R.id.bottom_profile:
                    Intent intent2 = new Intent(Activity.this, Profile.class);
                    intent2.putExtra("email", email);
                    intent2.putExtra("password", password);
                    startActivity(intent2);
                    overridePendingTransition(R.anim.slid_in_right, R.anim.slide_out_left);
                    finish();
                    return true;
            }
            return false;
        });

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        //statusTextView = findViewById(R.id.statusTextView);
        activityStandingConfidenceTextView = findViewById(R.id.activityStanding);
        activitySittingConfidenceTextView = findViewById(R.id.activitySitting);
        activityWalkingConfidenceTextView = findViewById(R.id.activityWalking);
        activityJumpingConfidenceTextView = findViewById(R.id.activityJumping);

        activitySt = findViewById(R.id.activitySta);
        activitySi = findViewById(R.id.activitySit);
        activityWa = findViewById(R.id.activityWal);
        activityJu = findViewById(R.id.activityJum);
    }
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            final float alpha = 0.8f;
            gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
            gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
            gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];

            linear_acceleration[0] = event.values[0] - gravity[0];
            linear_acceleration[1] = event.values[1] - gravity[1];
            linear_acceleration[2] = event.values[2] - gravity[2];

            // Determine the activity based on the accelerometer data
            int activity = getActivity(linear_acceleration);

            // Update the confidence values in the table
            confidenceValues[activity] += 1;
            int totalConfidence = 0;
            for (int i = 0; i < confidenceValues.length; i++) {
                totalConfidence += confidenceValues[i];
            }
            if (totalConfidence > 0) {
                activityStandingConfidenceTextView.setText((confidenceValues[0] * 100 / totalConfidence) + "%");
                activitySittingConfidenceTextView.setText((confidenceValues[1] * 100 / totalConfidence) + "%");
                activityWalkingConfidenceTextView.setText((confidenceValues[2] * 100 / totalConfidence) + "%");
                activityJumpingConfidenceTextView.setText((confidenceValues[3] * 100 / totalConfidence) + "%");
                // Set the background color of the activity with the highest confidence to blue
                int maxConfidenceIndex = 0;
                int maxConfidenceValue = confidenceValues[0];
                for (int i = 1; i < confidenceValues.length; i++) {
                    if (confidenceValues[i] > maxConfidenceValue) {
                        maxConfidenceIndex = i;
                        maxConfidenceValue = confidenceValues[i];
                    }
                }
                switch (maxConfidenceIndex) {
                    case 0:
                        activityStandingConfidenceTextView.setBackgroundColor(getResources().getColor(R.color.teal_700));
                        activitySt.setBackgroundColor(getResources().getColor(R.color.teal_700));
                        break;
                    case 1:
                        activitySittingConfidenceTextView.setBackgroundColor(getResources().getColor(R.color.teal_700));
                        activitySi.setBackgroundColor(getResources().getColor(R.color.teal_700));
                        break;
                    case 2:
                        activityWalkingConfidenceTextView.setBackgroundColor(getResources().getColor(R.color.teal_700));
                        activityWa.setBackgroundColor(getResources().getColor(R.color.teal_700));
                        break;
                    case 3:
                        activityJumpingConfidenceTextView.setBackgroundColor(getResources().getColor(R.color.teal_700));
                        activityJu.setBackgroundColor(getResources().getColor(R.color.teal_700));
                        break;
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used
    }

    private int getActivity(float[] acceleration) {
        // Determine the activity based on the accelerometer data
        int activity;
        float x = acceleration[0];
        float y = acceleration[1];
        float z = acceleration[2];

        float magnitude = (float) Math.sqrt(x * x + y * y + z * z);

        if (magnitude < 2.0f) {
            activity = 0; // Standing
        } else if (magnitude < 5.0f) {
            activity = 1; // Sitting
        } else if (magnitude < 8.0f) {
            activity = 2; // Walking
        } else {
            activity = 3; // Jumping
        }
        return activity;
    }
}